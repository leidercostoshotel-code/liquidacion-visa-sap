#!/usr/bin/env bash
# Crea el repositorio en GitHub, sube el código y activa GitHub Pages.
#
#   Uso:  ./publicar.sh SU-USUARIO-DE-GITHUB [nombre-del-repo]
#
# Requiere GitHub CLI: https://cli.github.com  —  autentíquese una vez con  gh auth login

set -euo pipefail

USUARIO="${1:-}"
REPO="${2:-liquidacion-visa-sap}"

if [ -z "$USUARIO" ]; then
  echo "Falta su usuario de GitHub."
  echo "Ejemplo:  ./publicar.sh leidertisnado"
  exit 1
fi

if ! command -v gh >/dev/null 2>&1; then
  echo "No está instalado GitHub CLI. Descárguelo de https://cli.github.com"
  exit 1
fi

gh auth status >/dev/null 2>&1 || { echo "Inicie sesión primero con:  gh auth login"; exit 1; }

# El commit ya viene hecho en la rama main. Si clonó este zip en otra carpeta sin .git, se inicializa.
if [ ! -d .git ]; then
  git init -b main
  git add -A
  git commit -m "Agrega el conversor de liquidación VISA a pestaña SAP"
fi

echo "Creando $USUARIO/$REPO…"
gh repo create "$USUARIO/$REPO" --public --source=. --remote=origin --push

echo "Activando GitHub Pages…"
gh api -X POST "repos/$USUARIO/$REPO/pages" \
  -f "source[branch]=main" -f "source[path]=/" >/dev/null 2>&1 \
  || gh api -X PUT "repos/$USUARIO/$REPO/pages" \
       -f "source[branch]=main" -f "source[path]=/" >/dev/null

echo
echo "Listo."
echo "  Repositorio: https://github.com/$USUARIO/$REPO"
echo "  Página:      https://$USUARIO.github.io/$REPO/"
echo
echo "La página tarda uno o dos minutos en estar disponible la primera vez."
