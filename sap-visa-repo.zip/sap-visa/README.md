# Liquidación VISA → SAP

Convierte el Excel de liquidación de tarjetas de Izipay en la pestaña **SAP** lista para
importar a SAP Business One. Una sola página, sin servidor ni instalación: abra
`index.html` en el navegador o publíquelo con GitHub Pages.

## Qué hace

1. **Lee el Excel.** Detecta sola la hoja que contiene la columna `COMERCIO/CADENA` y usa
   la hoja `Datos` como catálogo de cuentas para los nombres.
2. **Agrupa las liquidaciones** por comercio y fecha de abono, separadas por las filas en
   blanco del reporte.
3. **Arma el asiento** de cada liquidación: crédito del importe bruto, débito de la comisión
   con su centro de costo y débito del neto a la cuenta del banco.
4. **Convierte a moneda local** con un tipo de cambio por cada fecha de abono.
5. **Exporta** un `.xlsx` con la hoja `SAP` y sus 22 columnas, importes como texto con
   prefijo de moneda (`USD 990.00`, `SOL 3,514.50`).

## Cómo decide la cuenta de crédito

| Caso | Cuenta |
| --- | --- |
| El grupo trae la etiqueta `ANTICIPO RECIBIDO` | cuenta de anticipo (121111101 por defecto) |
| La etiqueta es un nombre con documento, ej. `MARTA FRUCTOS 01-F005-0004434` | cuenta de cliente (102111101 por defecto) |
| El grupo no trae etiqueta | cuenta configurada para ese comercio |

Las etiquetas se emparejan por posición con las transacciones del grupo, y las líneas que
comparten cuenta y glosa se consolidan en una sola.

## Cálculo de la comisión

La comisión del asiento es **importe bruto − importe neto**, no `COMISIÓN TOTAL + IGV`.

Ambas fórmulas coinciden en las liquidaciones normales. Se separan cuando el grupo incluye
una devolución: ahí el reporte revierte la comisión cobrada sin declararla en ninguna
columna, y solo la diferencia bruto − neto deja el asiento cuadrado. La aplicación avisa en
esos grupos y muestra las dos cifras.

Los importes en moneda local se redondean a dos decimales. La opción *Ajustar el redondeo en
la línea del banco* traslada a esa línea la diferencia de céntimos para que débitos y
créditos cuadren exactamente.

## Opciones de exportación

- Fila en blanco entre asientos.
- Separar socio de negocios y documento en sus propias columnas.
- Llenar `Fecha Registro Ventas` con la fecha de abono.
- Filtrar por fecha de abono o comercio y exportar solo los asientos marcados.

## Tecnología

HTML, CSS y JavaScript sin framework. La única dependencia es
[SheetJS](https://sheetjs.com) 0.18.5, cargada desde CDN, para leer y escribir el `.xlsx`.
Ningún dato sale del navegador: todo el procesamiento es local.

## Estructura

```
index.html    la aplicación completa
```

---

Leider Tisnado Mego · Soluciones Digitales
